package com.cg.payroll;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgPayrollPortalSpringBootMvcjpadatarestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgPayrollPortalSpringBootMvcjpadatarestApplication.class, args);
	}

}
